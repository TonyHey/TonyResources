sap.ui.controller("sap.rds.bdi.stream.logConfig.views.table", {

    onInit : function() {

    }

});