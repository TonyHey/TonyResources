sap.ui.controller("sap.rds.bdi.stream.Homepage.view.detailPage.alertsAnalysis.visitDurationChartContainer", {

});