sap.ui.controller("sap.rds.bdi.stream.Homepage.view.predictive.predictive", {

    onInit: function() {

    },

    onBeforeRendering: function() {

    },

    onAfterRendering: function() {
        
    },

    onExit: function() {

    }
});