sap.ui.controller("sap.rds.bdi.stream.Homepage.view.topLocations.topLocations", {
    
    onInit: function() {

    },

    onBeforeRendering: function() {

    },

    onAfterRendering: function() {
        
    },

    onExit: function() {

    }

});