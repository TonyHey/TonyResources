sap.ui.controller("sap.rds.bdi.stream.Homepage.view.detailPage.alertsAnalysis.visitDurationCharts.columnChart", {

	onInit: function() {

	},

	onBeforeRendering: function() {

	},

	onAfterRendering: function() {

	},

	onExit: function() {

	}

});